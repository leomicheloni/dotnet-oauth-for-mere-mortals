---
name: Code refactoring
about: Any code improvements which make the code better
title: '[Refactoring]: '
assignees: 'FabianGosebrink'
labels: ['refactoring']
---
