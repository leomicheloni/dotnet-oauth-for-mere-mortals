# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 13.x    | :white_check_mark: |
| 12.x    | :white_check_mark: |
| < 12    | :x:                |

## Reporting a Vulnerability

Please report here: angular-oidc@outlook.com
