This certificate is only an example. Please use your own.

Double click the pfx on a windows mc and use the 1234 password to install. 

The certificates are configured in the angular.json

