export enum LogLevel {
  None,
  Debug,
  Warn,
  Error,
}
