export interface ParResponse {
  requestUri: string;
  expiresIn: number;
}
