export interface PopupOptions {
  width?: number;
  height?: number;
  left?: number;
  top?: number;
}
